
# pro_app/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('g/', views.photo_list, name='photo'),
    path('', views.main, name='home'),
    # Add more URL patterns for your app here

    path('upload/', views.upload_photo, name='upload_photo'),
    
    path('v/', views.upload_video, name='upload_video'),
]