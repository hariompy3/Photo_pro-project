from django.shortcuts import render
from .models import *
from django.db.models import Q
from itertools import chain
from operator import attrgetter

def photo_list(request):
    photos = Photo.objects.all().order_by('-uploaded_at')
    videos = Video.objects.all().order_by('-uploaded_at')
    
    all_items = sorted(
        chain(photos, videos),
        key=attrgetter('uploaded_at'),
        reverse=True
    )
    
    # Add a 'type' attribute to each item
    for item in all_items:
        item.type = 'photo' if isinstance(item, Photo) else 'video'
    
    context = {
        'all_items': all_items,
        'photos': photos,
        'videos': videos,
    }
    return render(request, 'photo_list.html', context)
    
def main(request):
    home_photos = HomePhoto.objects.select_related('photo').all()
    return render(request, 'main.html', {'home_photos': home_photos})

    
    
    
    
    
    
    
    
    
    
    

from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import PhotoUploadForm

def upload_photo(request):
    if request.method == 'POST':
        form = PhotoUploadForm(request.POST, request.FILES)
        if form.is_valid():
            photo = form.save(commit=False)
            photo.save()
            messages.success(request, 'Photo uploaded successfully!')
            return redirect('photo')  # Assume you have a view to list photos
    else:
        form = PhotoUploadForm()
    
    return render(request, 'upload_photo.html', {'form': form})
    
    
    
    
# views.py
from django.shortcuts import render, redirect
from .forms import VideoUploadForm

def upload_video(request):
    if request.method == 'POST':
        form = VideoUploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('photo')  # Redirect to video list page
    else:
        form = VideoUploadForm()
    return render(request, 'upload_video.html', {'form': form})    