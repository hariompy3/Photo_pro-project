from django.db import models

class Photo(models.Model):
    title = models.CharField(max_length=200)
    image = models.ImageField(upload_to='photos/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    width = models.IntegerField()
    height = models.IntegerField()

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        from PIL import Image
        img = Image.open(self.image)
        self.width, self.height = img.size
        super().save(*args, **kwargs) 
        
        
        
import os

class Video(models.Model):
    title = models.CharField(max_length=500)
    video_file = models.FileField(upload_to='videos/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
  
    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)  # Save the model first to ensure the file is saved

    def delete(self, *args, **kwargs):
        # Delete the file when the model instance is deleted
        if self.video_file:
            if os.path.isfile(self.video_file.path):
                os.remove(self.video_file.path)
        super().delete(*args, **kwargs)
        
        
        
        
        
        


class HomePhoto(models.Model):
    photo = models.ForeignKey(Photo, on_delete=models.CASCADE, related_name='home_photos')
    order = models.IntegerField(default=0)  # This field allows you to control the order of photos on the home page

    def __str__(self):
        return f"Home Photo: {self.photo.title}"

    class Meta:
        ordering = ['order']  # This will ensure that the photos are always retrieved in the specified order