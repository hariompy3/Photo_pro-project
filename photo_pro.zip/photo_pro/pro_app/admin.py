

from django.contrib import admin
from .models import *

admin.site.register(Photo)
admin.site.register(Video)

admin.site.register(HomePhoto)